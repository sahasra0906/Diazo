# DIAZO — Smart Food Scale (ESP32) Integration Guide

The ESP32 does **two jobs**:

1. **Send** the food weight to the backend (POST).
2. **Ask** the backend what colour the LED should be (GET), after the patient logs the meal.

Patients can also type the amount by hand, so the scale is optional.

---

## 0. Quick facts (read this first)

| Thing | Value |
|---|---|
| Base URL (deployed) | `https://<backend-url>` (Render) |
| Base URL (local test) | `http://<your-computer-LAN-IP>:8000` (ESP32 + computer on the same Wi-Fi; **not** `localhost`) |
| Auth | Header `X-Device-Key: <shared secret>` on **every** device request |
| Weight field name | `weight_g` (**grams**, a number > 0 and ≤ 5000) |
| `device_id` | text, 3–100 characters, e.g. `scale-01` |
| `patient_id` | the patient's UUID (fixed in firmware) |

> Render free tier sleeps when idle. The first request after a pause can take 30–60 s. Use a long HTTP timeout (see code) and retry.

---

## 1. Job 1 — send the weight

```
POST {BASE_URL}/api/v1/hardware/meal-weight-readings
Content-Type: application/json
X-Device-Key: <shared secret>
```

Body:

```json
{
  "patient_id": "265f7e92-63fd-49e1-a933-65a2fa479d3e",
  "device_id": "scale-01",
  "weight_g": 184.5
}
```

Success: HTTP **201** and a JSON reply like:

```json
{
  "id": "…uuid…",
  "patient_id": "265f7e92-63fd-49e1-a933-65a2fa479d3e",
  "device_id": "scale-01",
  "weight_g": 184.5
}
```

Send a reading only once the load cell value has **settled**.

| Code | Meaning |
|---|---|
| 201 | Saved and pushed live to the patient's dashboard |
| 401 | Wrong or missing `X-Device-Key`, or the key is not set on the server |
| 404 | `patient_id` doesn't exist or isn't a patient |
| 422 | Bad body, e.g. wrong field name (`weight_g` is **wrong**, use `weight_g`), `device_id` too short, or weight ≤ 0 or > 5000 |

---

## 2. Job 2 — get the LED colour

After the patient picks a food and logs the meal in the app, the backend stores the result for your `device_id`. The ESP32 polls it:

```
GET {BASE_URL}/api/v1/hardware/scale-status/scale-01
X-Device-Key: <shared secret>
```

Reply (200):

```json
{
  "device_id": "scale-01",
  "patient_id": "265f7e92-63fd-49e1-a933-65a2fa479d3e",
  "status": "GREEN",
  "updated_at": "2026-09-06T13:50:00Z"
}
```

| `status` | LED |
|---|---|
| `GREEN` | Meal is within the patient's carb target |
| `RED` | Meal is above target |
| `PENDING` | Nothing evaluated yet, LED off or neutral |

**Important:** a **404 "Device not found" is normal** until the first meal has been logged with this scale. Treat 404 as `PENDING`, don't treat it as an error.

Poll every ~3–5 seconds while the scale is in use. No need to poll constantly.

---

## 3. Full example (Arduino / ESP32)

```cpp
#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>   // Library Manager: "ArduinoJson" by Benoit Blanchon

// ---- EDIT THESE ----
const char* WIFI_SSID   = "YOUR_WIFI_SSID";
const char* WIFI_PASS   = "YOUR_WIFI_PASSWORD";
const char* BASE_URL    = "https://YOUR-BACKEND.onrender.com";  // no trailing slash
const char* DEVICE_KEY  = "PASTE_THE_SHARED_SECRET_HERE";
const char* PATIENT_ID  = "265f7e92-63fd-49e1-a933-65a2fa479d3e";
const char* DEVICE_ID   = "scale-01";
const int LED_GREEN_PIN = 26;
const int LED_RED_PIN   = 27;
// --------------------

void connectWifi() {
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  while (WiFi.status() != WL_CONNECTED) { delay(500); }
}

// Returns true if the backend answered 201.
bool sendWeightReading(float weightG) {
  if (WiFi.status() != WL_CONNECTED) connectWifi();

  WiFiClientSecure client;
  client.setInsecure();               // OK for a prototype. Pin the cert for real use.
  HTTPClient http;
  http.setTimeout(60000);             // Render free tier can be slow to wake up
  http.begin(client, String(BASE_URL) + "/api/v1/hardware/meal-weight-readings");
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-Device-Key", DEVICE_KEY);

  String body = String("{\"patient_id\":\"") + PATIENT_ID +
                "\",\"device_id\":\"" + DEVICE_ID +
                "\",\"weight_g\":" + String(weightG, 1) + "}";

  int code = http.POST(body);
  Serial.printf("POST -> %d\n", code);   // 201 = ok, 401 = key, 422 = body
  if (code != 201) Serial.println(http.getString());
  http.end();
  return code == 201;
}

// Updates the LEDs from the backend status.
void pollLedStatus() {
  if (WiFi.status() != WL_CONNECTED) connectWifi();

  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  http.setTimeout(60000);
  http.begin(client, String(BASE_URL) + "/api/v1/hardware/scale-status/" + DEVICE_ID);
  http.addHeader("X-Device-Key", DEVICE_KEY);

  int code = http.GET();
  String status = "PENDING";                       // 404 also means PENDING
  if (code == 200) {
    JsonDocument doc;
    if (!deserializeJson(doc, http.getString())) {
      status = doc["status"].as<String>();
    }
  }
  http.end();

  digitalWrite(LED_GREEN_PIN, status == "GREEN" ? HIGH : LOW);
  digitalWrite(LED_RED_PIN,   status == "RED"   ? HIGH : LOW);
  Serial.println("LED status: " + status);
}

void setup() {
  Serial.begin(115200);
  pinMode(LED_GREEN_PIN, OUTPUT);
  pinMode(LED_RED_PIN, OUTPUT);
  connectWifi();
}

void loop() {
  // 1) When your load cell value has settled:
  //    float w = readStableWeightGrams();
  //    if (w > 0) sendWeightReading(w);

  // 2) Check the LED colour every few seconds:
  pollLedStatus();
  delay(4000);
}
```

(`JsonDocument` needs ArduinoJson 7. On version 6 use `StaticJsonDocument<256> doc;`.)

---

## 4. Test WITHOUT the hardware (do this first!)

Open `https://<backend-url>/docs`, find the **hardware** section, click **Authorize/Try it out** and send the same headers and body. If this works but the ESP32 doesn't, the problem is in the firmware or Wi-Fi.

```bash
# send a weight
curl -X POST https://<backend-url>/api/v1/hardware/meal-weight-readings \
  -H "Content-Type: application/json" \
  -H "X-Device-Key: <the shared secret>" \
  -d '{"patient_id":"265f7e92-63fd-49e1-a933-65a2fa479d3e","device_id":"scale-01","weight_g":184.5}'

# read the LED status
curl https://<backend-url>/api/v1/hardware/scale-status/scale-01 \
  -H "X-Device-Key: <the shared secret>"
```

## 5. Troubleshooting

| Symptom | Likely cause |
|---|---|
| HTTP 422 | Field is `weight_g`, not `weight_g`. `device_id` must be 3+ chars. |
| HTTP 401 | `X-Device-Key` doesn't match the backend's `ESP32_DEVICE_API_KEY` (must be set on Render too) |
| Negative code like -1 or timeout | Wi-Fi down, wrong URL, or Render still waking up. Raise the timeout and retry. |
| Local test fails | Used `localhost`. Use your computer's LAN IP, and allow port 8000 in the firewall. |
| Scale-status always 404 | Normal until a meal is logged in the app **with a scale reading** (the app sends the `device_id`) |
| Dashboard doesn't show the weight | Patient must be logged in with the dashboard open; `patient_id` must be that patient's UUID |

## 6. Known limitations (by design)

- One shared device key, not per-device tokens.
- `patient_id` is fixed in firmware; there is no device-pairing flow yet.
- The LED status is polled (no push to the device).
